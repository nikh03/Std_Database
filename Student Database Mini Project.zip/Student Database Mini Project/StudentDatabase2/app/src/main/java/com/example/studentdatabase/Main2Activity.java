package com.example.studentdatabase;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    private Button LogOut;
    DatabaseHelper myDB;
    EditText editTextId, editName, editEmail, editCC;
    Button buttonAdd, buttonGetData, buttonUpdate, buttonDelete, buttonViewAll, button_ExportToExcel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        myDB = new DatabaseHelper(this);

        editTextId = findViewById(R.id.editText_id);
        editName = findViewById(R.id.editText_name);
        editEmail = findViewById(R.id.editText_email);
        editCC = findViewById(R.id.editText_CC);


        buttonAdd = findViewById(R.id.button_add);
        buttonDelete = findViewById(R.id.button_delete);
        buttonUpdate = findViewById(R.id.button_update);
        buttonGetData = findViewById(R.id.button_view);
        buttonViewAll = findViewById(R.id.button_viewALL);

        LogOut = findViewById(R.id.logout);
        //button_ExportToExcel = findViewById(R.id.button_ExportToExcel);

        AddData();
        getData();
        viewAll();
        updateData();
        deleteData();

        LogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(true){

                    Intent MainIntent = new Intent(Main2Activity.this,MainActivity.class);
                    startActivity(MainIntent);
                    finish();
                    Toast.makeText(Main2Activity.this,"Log Out!",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void AddData() {
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = editTextId.getText().toString();
                String name= editName.getText().toString();
                String email = editEmail.getText().toString();
                String course = editCC.getText().toString();


                if(id.equals(String.valueOf(""))) {
                    editTextId.setError("Enter ID");
                    return;
                }
                if(name.equals(String.valueOf(""))) {
                    editName.setError("Enter Name");
                    return;
                }
                if(email.equals(String.valueOf(""))) {
                    editEmail.setError("Enter Email");
                    return;
                }
                if(course.equals(String.valueOf(""))) {
                    editCC.setError("Enter Courses");
                    return;
                }


                boolean isInserted= myDB.insertData(editTextId.getText().toString(),editName.getText().toString(), editEmail.getText().toString(), editCC.getText().toString());
                if (isInserted == true) {
                    Toast.makeText(Main2Activity.this, "Data Inserted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Main2Activity.this, "Wrong Entries", Toast.LENGTH_SHORT).show();
                }
                editTextId.setText("");
                editEmail.setText("");
                editName.setText("");
                editCC.setText("");
                closeKeyboard();

                //Toast.makeText(MainActivity.this, "test", Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void getData() {
        buttonGetData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = editTextId.getText().toString();

                if(id.equals(String.valueOf(""))) {
                    editTextId.setError("Enter ID");
                    return;
                }

                Cursor cursor = myDB.getData(id);
                String data = null;

                if(cursor.moveToNext()) {
                    data = "ID: "+ cursor.getString(0) +"\n"+
                            "Name : "+ cursor.getString(1) +"\n"+
                            "Email: "+ cursor.getString(2) +"\n"+
                            "Courses: "+ cursor.getString(3) +"\n";
                }
                showMessage("Data: ",data);
                editTextId.setText("");
                editEmail.setText("");
                editName.setText("");
                editCC.setText("");
                closeKeyboard();
            }

        });
    }
    public void viewAll() {
        buttonViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor cursor = myDB.getAllData();

                //Small Test
                if (cursor.getCount() == 0) {
                    showMessage("Error","No Entries found in Database");
                    return;
                }

                StringBuffer buffer = new StringBuffer();

                while (cursor.moveToNext()) {
                    buffer.append("ID:"+cursor.getString(0)+"\n");
                    buffer.append("Name:"+cursor.getString(1)+"\n");
                    buffer.append("Email:"+cursor.getString(2)+"\n");
                    buffer.append("Courses:"+cursor.getString(3)+"\n\n");
                }
                showMessage("All Data", buffer.toString());
                editTextId.setText("");
                editEmail.setText("");
                editName.setText("");
                editCC.setText("");
            }
        });
    }
    public void updateData() {
        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = editTextId.getText().toString();
                if(id.equals(String.valueOf(""))) {
                    editTextId.setError("Enter ID");
                    return;
                }

                boolean isUpadate = myDB.updateData(editTextId.getText().toString(),
                        editName.getText().toString(),
                        editEmail.getText().toString(),
                        editCC.getText().toString());

                if (isUpadate == true) {
                    Toast.makeText(Main2Activity.this, "Data Updated Successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Main2Activity.this, "Oops!! Data is Not Updated", Toast.LENGTH_SHORT).show();
                }
                editTextId.setText("");
                editEmail.setText("");
                editName.setText("");
                editCC.setText("");
                closeKeyboard();
            }
        });
    }
    public void deleteData() {
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String id = editTextId.getText().toString();
                if(id.equals(String.valueOf(""))) {
                    editTextId.setError("Enter ID");
                    return;
                }
                Integer deletedRow = myDB.deleteData(editTextId.getText().toString());

                if (deletedRow > 0) {
                    Toast.makeText(Main2Activity.this, "Deleted Successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Main2Activity.this, "Oops!! Delete Unsuccessful", Toast.LENGTH_SHORT).show();
                }
                editTextId.setText("");
                editEmail.setText("");
                editName.setText("");
                editCC.setText("");
                closeKeyboard();
            }
        });
    }

    private void showMessage(String title, String message){
        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.create();
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view !=null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }


}
