package com.example.studentdatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText Name;
    private EditText Password;
    private TextView Info;
    private Button Login;
    private int counter = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name = (EditText) findViewById(R.id.username2);
        Password = (EditText) findViewById(R.id.password);
        Info = (TextView) findViewById(R.id.textView);
        Login = (Button) findViewById(R.id.login);

        Info.setText("No of attempts remaining: 5");

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Name1 =Name.getText().toString();
                String Pwd = Password.getText().toString();
                if(Name1.equalsIgnoreCase("Admin") && Pwd.equals("nikh")){

                    Intent MainIntent = new Intent(MainActivity.this,Main2Activity.class);

                    Name.setText("");
                    Password.setText("");

                    startActivity(MainIntent);
                    Toast.makeText(MainActivity.this,"Log in!",Toast.LENGTH_SHORT).show();
                }else
                    {
                        Toast.makeText(MainActivity.this,"Enter correct User Name and Password",Toast.LENGTH_LONG).show();
                        counter--;

                        Info.setText("No of attempts remaining: "+String.valueOf(counter));

                        if(counter == 0) {
                            Login.setEnabled(false);
                        }
                }

                //validate(Name.getText().toString(), Password.getText().toString());
            }
        });

    }

   /* private void validate(String userName, String userPass) {

        if((userName == "Nik") && (userPass == "1234")) {
            Intent intent = new Intent(MainActivity.this, Main2Activity.class);
            startActivity(intent);
            Toast.makeText(MainActivity.this,"Log in",Toast.LENGTH_SHORT).show();


        }
        /*else {
            counter--;

            Info.setText("No of attempts remaining: "+String.valueOf(counter));

            if(counter == 0) {
                Login.setEnabled(false);
            }
        }*/
    //}
}
